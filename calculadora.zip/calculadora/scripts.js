var botoes = document.querySelectorAll(".calc_botao"); // Guarda os elementos dos botões de números
var botoesOp = document.querySelectorAll(".calc_botao_op"); // Guarda os elementos dos botões de operadores
var botaoRes = document.querySelector(".calc_botao_res"); // Guarda o elemento do botão de resposta
var botoesFun = document.querySelectorAll(".calc_botao_fun"); // Guarda os elementos dos botões de função
var resposta = document.querySelector("#res"); // Guarda o elemento do input
var num = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
var virgula = false;
resposta.setAttribute("disabled", "true"); // Desabilita o input do teclado no visor
function digitar(n){
    if(n == "." && virgula == false){
        resposta.value = resposta.value + n;
        virgula = true;
    }
    if(n in num){
        resposta.value = resposta.value + n;
    }
    if(n == "c"){
        resposta.value = "0";
        virgula = false;
    }
    if(resposta.value[0] == "0" && resposta.value != "."){
        if(resposta.value[1] == "0"){
            resposta.value = "0";
        }
        if(n != "0" && n != "c"){
            return
        }
    }
    if(resposta.value[0] == "."){
        resposta.value = "0.";
    }
    if(resposta.value.length <= 2 && resposta.value[0] == "0"){
        resposta.value = "teste";
    }
}